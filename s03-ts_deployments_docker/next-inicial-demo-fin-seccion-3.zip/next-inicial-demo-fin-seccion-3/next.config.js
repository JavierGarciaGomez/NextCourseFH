module.exports = {
  reactStrictMode: true,
  experimental: {
    outputStandalone: true
  }
}
